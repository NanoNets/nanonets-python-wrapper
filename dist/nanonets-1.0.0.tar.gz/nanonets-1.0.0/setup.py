from setuptools import setup, find_packages

NAME = "nanonets"
VERSION = "1.0.0"

REQUIRES = [line.strip() for line in open("requirements.txt").readlines()]

setup(
    name=NAME,
    version=VERSION,
    description="The Nanonets API",
    author_email="support@nanonets.com",
    url="https://nanonets.com",
    install_requires=REQUIRES,
    packages=find_packages(),
    include_package_data=True,
)